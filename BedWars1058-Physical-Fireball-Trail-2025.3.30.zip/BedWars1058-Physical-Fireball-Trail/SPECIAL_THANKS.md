I want to thank you all that helped the development of this plugin.
Casual order. If I forgot to add you on this list please contact me.

- FoviOX
- Mr. Ceasar
- Fabian03
- MrDarkness462
- 𝐌𝐚𝐫𝐜𝐞𝐥𝐞𝐤𝐭𝐫𝐨
- Barnaby
- Ryan DeTree
- Dragoș (gamster.org)
- J.T. McQuigg (JT122406)

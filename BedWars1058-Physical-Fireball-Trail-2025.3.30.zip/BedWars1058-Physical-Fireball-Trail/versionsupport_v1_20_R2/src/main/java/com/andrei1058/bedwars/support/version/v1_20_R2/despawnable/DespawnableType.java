package com.andrei1058.bedwars.support.version.v1_20_R2.despawnable;

public enum DespawnableType {
    IRON_GOLEM,
    SILVERFISH
}

package com.andrei1058.bedwars.support.version.v1_19_R2.despawnable;

@Deprecated
public enum DespawnableType {
    IRON_GOLEM,
    SILVERFISH
}

package com.andrei1058.bedwars.listeners;

import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.arena.Arena;
import com.andrei1058.bedwars.arena.LastHit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

import java.util.Collection;

import static com.andrei1058.bedwars.BedWars.config;
import static com.andrei1058.bedwars.BedWars.getAPI;

public class FireballListener implements Listener {

    private final double fireballExplosionSize;
    private final boolean fireballMakeFire;
    private final double fireballKnockbackForce;  // 基础击退力 F

    private final double damageSelf;
    private final double damageEnemy;
    private final double damageTeammates;

    public FireballListener() {
        this.fireballExplosionSize = config.getYml().getDouble(ConfigPath.GENERAL_FIREBALL_EXPLOSION_SIZE);
        this.fireballMakeFire = config.getYml().getBoolean(ConfigPath.GENERAL_FIREBALL_MAKE_FIRE);
        this.fireballKnockbackForce = config.getYml().getDouble(ConfigPath.GENERAL_FIREBALL_KNOCKBACK_FORCE);

        this.damageSelf = config.getYml().getDouble(ConfigPath.GENERAL_FIREBALL_DAMAGE_SELF);
        this.damageEnemy = config.getYml().getDouble(ConfigPath.GENERAL_FIREBALL_DAMAGE_ENEMY);
        this.damageTeammates = config.getYml().getDouble(ConfigPath.GENERAL_FIREBALL_DAMAGE_TEAMMATES);
    }

    @EventHandler
    public void fireballHit(ProjectileHitEvent e) {
        if (!(e.getEntity() instanceof Fireball)) return;
        Location explosionLoc = e.getEntity().getLocation();

        ProjectileSource projectileSource = e.getEntity().getShooter();
        if (!(projectileSource instanceof Player)) return;
        Player source = (Player) projectileSource;

        IArena arena = Arena.getArenaByPlayer(source);
        World world = explosionLoc.getWorld();
        if (world == null) return;

        Collection<Entity> nearbyEntities = world.getNearbyEntities(
                explosionLoc, fireballExplosionSize, fireballExplosionSize, fireballExplosionSize);

        for (Entity entity : nearbyEntities) {
            if (!(entity instanceof Player)) continue;
            Player player = (Player) entity;
            if (!getAPI().getArenaUtil().isPlaying(player)) continue;

            // 使用玩家眼睛位置计算方向向量，确保获得更明显的垂直分量
            Vector explosionVector = explosionLoc.toVector();
            Vector playerVector = player.getEyeLocation().toVector();
            Vector direction = playerVector.subtract(explosionVector).normalize();

            // 分离水平（XZ）和垂直（Y）分量
            Vector horizontalDir = new Vector(direction.getX(), 0, direction.getZ());
            double horizontalLength = horizontalDir.length();
            Vector knockback;
            double F = fireballKnockbackForce; // 基础击退力

            if (horizontalLength < 0.0001) {
                // 如果水平分量几乎为0，则为纯竖直情况
                knockback = new Vector(0, direction.getY() * F, 0);
            } else {
                // 归一化水平向量并计算水平击退
                horizontalDir.normalize();
                knockback = horizontalDir.multiply(F);
                // 垂直击退力根据方向的 Y 分量计算
                knockback.setY(direction.getY() * F);
            }

            // 如果火球位于玩家下方（即玩家眼高大于爆炸位置），则进行特殊调整
            if (explosionLoc.getY() < player.getEyeLocation().getY()) {
                // 当玩家处于地面且静止时（近似判断：Y速度接近0），设置为 14 格跳跃效果（Y约为 1.5）
                if (player.isOnGround() && Math.abs(player.getVelocity().getY()) < 0.1) {
                    knockback.setY(1.5);
                }
                // 当玩家已经处于跳跃状态时（Y速度正且较大），设置为 17 格跳跃效果（Y约为 1.65）
                else if (!player.isOnGround() && player.getVelocity().getY() > 0) {
                    knockback.setY(1.65);
                }
            }

            // 叠加部分玩家原有速度（保留惯性效果，可根据需要调整系数）
            Vector finalVelocity = player.getVelocity().multiply(0.2).add(knockback);
            player.setVelocity(finalVelocity);

            // 记录最后击中信息
            LastHit lh = LastHit.getLastHit(player);
            if (lh != null) {
                lh.setDamager(source);
                lh.setTime(System.currentTimeMillis());
            } else {
                new LastHit(player, source, System.currentTimeMillis());
            }

            // 处理伤害逻辑
            if (player.equals(source)) {
                if (damageSelf > 0) {
                    player.damage(damageSelf);
                }
            } else if (arena.getTeam(player).equals(arena.getTeam(source))) {
                if (damageTeammates > 0) {
                    player.damage(damageTeammates);
                }
            } else {
                if (damageEnemy > 0) {
                    player.damage(damageEnemy);
                }
            }
        }
    }

    @EventHandler
    public void fireballDirectHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Fireball)) return;
        if (!(e.getEntity() instanceof Player)) return;
        if (Arena.getArenaByPlayer((Player) e.getEntity()) == null) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void fireballPrime(ExplosionPrimeEvent e) {
        if (!(e.getEntity() instanceof Fireball)) return;
        ProjectileSource shooter = ((Fireball) e.getEntity()).getShooter();
        if (!(shooter instanceof Player)) return;
        Player player = (Player) shooter;
        if (Arena.getArenaByPlayer(player) == null) return;
        e.setFire(fireballMakeFire);
    }
}

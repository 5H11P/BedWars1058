package com.andrei1058.bedwars.support.version.v1_20_R3.despawnable;

public enum DespawnableType {
    IRON_GOLEM,
    SILVERFISH
}

package com.andrei1058.bedwars.api.arena.stats;

public interface Incrementable {

    void increment();
}

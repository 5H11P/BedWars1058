package com.andrei1058.bedwars.support.version.v1_20_R1.despawnable;

@Deprecated
public enum DespawnableType {
    IRON_GOLEM,
    SILVERFISH
}

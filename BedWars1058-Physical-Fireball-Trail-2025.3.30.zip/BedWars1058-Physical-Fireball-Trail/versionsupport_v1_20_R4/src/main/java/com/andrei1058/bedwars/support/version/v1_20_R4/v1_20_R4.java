package com.andrei1058.bedwars.support.version.v1_20_R4;

import com.andrei1058.bedwars.support.version.v1_20_R3.v1_20_R3;
import org.bukkit.plugin.Plugin;

@SuppressWarnings("unused")
public class v1_20_R4 extends v1_20_R3 {

    public v1_20_R4(Plugin plugin, String name) {
        super(plugin, name);
    }
}